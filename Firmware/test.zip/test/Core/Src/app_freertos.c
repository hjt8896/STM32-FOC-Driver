/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : app_freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "event_groups.h"
#include "fdcan.h"
#include "adc.h"
#include "opamp.h"
#include "tim.h"
#include "encoder.h"
#include "motor_ctl.h"
#include "speed_position_sensor.h"
#include "current_sensor.h"
#include "my_utilities.h"
#include "spi.h"
#include "hardware_it.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */
//extern uint16_t electronic_angle_s16;


/* USER CODE END Variables */
/* Definitions for defaultTask */
osThreadId_t defaultTaskHandle;
const osThreadAttr_t defaultTask_attributes = {
  .name = "defaultTask",
  .priority = (osPriority_t) osPriorityLow,
  .stack_size = 512 * 4
};
/* Definitions for FDCAN_Task */
osThreadId_t FDCAN_TaskHandle;
const osThreadAttr_t FDCAN_Task_attributes = {
  .name = "FDCAN_Task",
  .priority = (osPriority_t) osPriorityLow,
  .stack_size = 1024 * 4
};
/* Definitions for myQueue01 */
osMessageQueueId_t myQueue01Handle;
const osMessageQueueAttr_t myQueue01_attributes = {
  .name = "myQueue01"
};
/* Definitions for myBinarySem01 */
osSemaphoreId_t myBinarySem01Handle;
const osSemaphoreAttr_t myBinarySem01_attributes = {
  .name = "myBinarySem01"
};
/* Definitions for myEvent01 */
osEventFlagsId_t myEvent01Handle;
const osEventFlagsAttr_t myEvent01_attributes = {
  .name = "myEvent01"
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

/* USER CODE END FunctionPrototypes */

void StartDefaultTask(void *argument);
void CAN_Communication(void *argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/* Hook prototypes */
void vApplicationIdleHook(void);

/* USER CODE BEGIN 2 */
static volatile uint32_t ulIdleCycleCount = 0UL;
void vApplicationIdleHook( void )
{
   /* vApplicationIdleHook() will only be called if configUSE_IDLE_HOOK is set
   to 1 in FreeRTOSConfig.h. It will be called on each iteration of the idle
   task. It is essential that code added to this hook function never attempts
   to block in any way (for example, call xQueueReceive() with a block time
   specified, or call vTaskDelay()). If the application makes use of the
   vTaskDelete() API function (as this demo application does) then it is also
   important that vApplicationIdleHook() is permitted to return to its calling
   function, because it is the responsibility of the idle task to clean up
   memory allocated by the kernel to any task that has since been deleted. */
    ulIdleCycleCount++;
}
float GetCPUUsage(void)
{
    static uint32_t ulLastIdleCycleCount = 0UL;
    static uint32_t ulLastTickCount = 0UL;
    float fCPUUsage;
    
    uint32_t ulCurrentTickCount = xTaskGetTickCount();
    uint32_t ulCurrentIdleCycleCount = ulIdleCycleCount;
    
    uint32_t ulTickDiff = ulCurrentTickCount - ulLastTickCount;
    uint32_t ulIdleDiff = ulCurrentIdleCycleCount - ulLastIdleCycleCount;

    if(ulTickDiff > 0)
    {
        fCPUUsage = 100.0f - (100.0f * (float)ulIdleDiff) / (float)ulTickDiff;
    }
    else
    {
        fCPUUsage = 0.0f;
    }
    
    ulLastIdleCycleCount = ulCurrentIdleCycleCount;
    ulLastTickCount = ulCurrentTickCount;
    
    if(fCPUUsage < 0.0f) fCPUUsage = 0.0f;
    if(fCPUUsage > 100.0f) fCPUUsage = 100.0f;
    
    return fCPUUsage;
}
/* USER CODE END 2 */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* Create the semaphores(s) */
  /* creation of myBinarySem01 */
  myBinarySem01Handle = osSemaphoreNew(1, 1, &myBinarySem01_attributes);

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* Create the queue(s) */
  /* creation of myQueue01 */
  myQueue01Handle = osMessageQueueNew (16, sizeof(uint16_t), &myQueue01_attributes);

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of defaultTask */
  defaultTaskHandle = osThreadNew(StartDefaultTask, NULL, &defaultTask_attributes);

  /* creation of FDCAN_Task */
  FDCAN_TaskHandle = osThreadNew(CAN_Communication, NULL, &FDCAN_Task_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* Create the event(s) */
  /* creation of myEvent01 */
  myEvent01Handle = osEventFlagsNew(&myEvent01_attributes);

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

}

/* USER CODE BEGIN Header_StartDefaultTask */
int16_t inc=1;
uint16_t add=0;
uint8_t mode_select=5;
//uint16_t time_stamp=0;
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void *argument)
{
  /* USER CODE BEGIN StartDefaultTask */
  /* Infinite loop */
	
	HAL_OPAMP_SelfCalibrate(&hopamp1);
	HAL_OPAMP_SelfCalibrate(&hopamp2);
	HAL_OPAMP_SelfCalibrate(&hopamp3);
	HAL_ADCEx_Calibration_Start(&hadc1,ADC_SINGLE_ENDED);
	HAL_ADCEx_Calibration_Start(&hadc2,ADC_SINGLE_ENDED);
	HAL_ADCEx_InjectedStart_IT(&hadc1);
	HAL_ADCEx_InjectedStart_IT(&hadc2);	
	HAL_OPAMP_Start(&hopamp1);
	HAL_OPAMP_Start(&hopamp2);
	HAL_OPAMP_Start(&hopamp3);

	HAL_SPI_Receive_DMA(&hspi1,dma_pointer,1);
//  HAL_TIM_Base_Start_IT(&htim4);
	HAL_TIM_Base_Start_IT(&htim3);

	hctrl1.Id_Set = 0;
	hctrl1.Id_ctrl_pid.Kp=0.01f;
	hctrl1.Id_ctrl_pid.Ki=100.f;
	hctrl1.Id_ctrl_pid.Kd=0;
	hctrl1.Id_ctrl_pid.Max_output=6;
	hctrl1.Id_ctrl_pid.Min_output=-6;
  hctrl1.Id_ctrl_pid.dt = 0.00005f;
	hctrl1.Id_ctrl_pid.Integral_limit = 1000.f;

	hctrl1.Iq_Set = 0;
	hctrl1.Iq_ctrl_pid.Kp=0.01f;
	hctrl1.Iq_ctrl_pid.Ki=100.f;
	hctrl1.Iq_ctrl_pid.Kd=0;
	hctrl1.Iq_ctrl_pid.Max_output=6;
	hctrl1.Iq_ctrl_pid.Min_output=-6;
  hctrl1.Iq_ctrl_pid.dt = 0.00005f;
	hctrl1.Iq_ctrl_pid.Integral_limit = 1000.f;
	
	hctrl1.speed_ctrl_pid.Kp = 0.4f;
	hctrl1.speed_ctrl_pid.Ki = 0.5f;
	hctrl1.speed_ctrl_pid.Max_output = 42.f;
	hctrl1.speed_ctrl_pid.Min_output = -42.f;
  hctrl1.speed_ctrl_pid.dt = 0.001f;
	hctrl1.speed_ctrl_pid.Integral_limit = 5000.f;

  hctrl1.angle_Set=0;
	hctrl1.position_ctrl_pid.Kp = 0.1f;
	hctrl1.position_ctrl_pid.Ki = 0.5f;
  hctrl1.position_ctrl_pid.Kd = 0.00015f;
	hctrl1.position_ctrl_pid.Max_output = 42.f;
	hctrl1.position_ctrl_pid.Min_output = -42.f;
  hctrl1.position_ctrl_pid.dt = 0.001f;
	hctrl1.position_ctrl_pid.Integral_limit = 10000.f;

	hcurrent_sensor1.dq_filter=1.f;
	hspeed_sensor1.speed_filter = 0.1f;
  for(;;)
  {
//	add+=inc;
//	circles = add/16383;
//	add%=16383;
//	hctrl1.angle_Set = add;
	if(mode_select==0){
  int16_t angle_mirror=hspeed_sensor1.mechanical_angle_us16;
  if((hctrl1.angle_Set<=8192)&&(angle_mirror>hctrl1.angle_Set+8191)){
  angle_mirror-=16384;
  }else if((hctrl1.angle_Set>8192)&&(angle_mirror<hctrl1.angle_Set-8191)){
  angle_mirror+=16384;
  }
  hctrl1.position_ctrl_pid.pre_error = hctrl1.position_ctrl_pid.error;
	hctrl1.position_ctrl_pid.error  = hctrl1.angle_Set - angle_mirror; //
	PID_Controller(&(hctrl1.position_ctrl_pid));



  __disable_irq();
	hctrl1.Iq_Set	=	hctrl1.position_ctrl_pid.output;
	__enable_irq();
 }else if(mode_select==1){
//	hctrl1.speed_Set = hctrl1.position_ctrl_pid.output;
	hctrl1.speed_ctrl_pid.pre_error = hctrl1.speed_ctrl_pid.error;
	hctrl1.speed_ctrl_pid.error  = hctrl1.speed_Set - hspeed_sensor1.delta_mechanical_angle_s16; //
//	hctrl1.speed_ctrl_pid.error -= hctrl1.speed_ctrl_pid.pre_error;
	PID_Controller(&(hctrl1.speed_ctrl_pid));
  __disable_irq();
	hctrl1.Iq_Set	=	hctrl1.speed_ctrl_pid.output;
	__enable_irq();
	}
//TIM4 PRS=15999 ARR = 999 1CNT=100us 100ms MAX
//			if((TIM4->CR1&(1<<0))==1){
//       TIM4->CR1&=~(1<<0);
//       time_stamp = TIM4->CNT;
//       TIM4->CNT = 0;
//     }
//       TIM4->CR1|=(1<<0); 

 osDelay(1);
	
  }
  /* USER CODE END StartDefaultTask */
}

/* USER CODE BEGIN Header_CAN_Communication */
uint8_t can_rxdata[8];

/**
* @brief Function implementing the FDCAN_Task thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_CAN_Communication */
void CAN_Communication(void *argument)
{
  /* USER CODE BEGIN CAN_Communication */
  /* Infinite loop */
  EventBits_t uxBits;
	uint16_t temp_angle;
	int16_t temp_speed;
	int16_t temp_Iq;
  for(;;)
  {
    uxBits=xEventGroupWaitBits(
					myEvent01Handle,	// The event group being tested.
					(1<<0) ,	// The bits within the event group to wait for.
					pdTRUE,			// BIT_0 and BIT_1 should be cleared before returning.
					pdTRUE,		// Don't wait for both bits, either bit will do.
					100 );	// Wait a maximum of 100ms for either bit to be set.
    if(uxBits==(1<<0)){
      HAL_FDCAN_GetRxMessage(&hfdcan1,FDCAN_RX_FIFO0,&pRxHeader1,can_rxdata);
      if((3&(can_rxdata[0]>>6))==1){//filter motor2 ID 
	    taskENTER_CRITICAL();
			temp_angle = hspeed_sensor1.mechanical_angle_us16;
			temp_speed = hspeed_sensor1.delta_mechanical_angle_s16;
			temp_Iq		 = (int16_t)(hcurrent_sensor1.Iq*819.2f);
			mode_select=((can_rxdata[0]>>3)&3);
	    taskEXIT_CRITICAL();
			can_tdata[0]=(temp_angle)>>8;
      can_tdata[1]=(temp_angle)&0xff;
      can_tdata[2]=(temp_speed)>>8;
      can_tdata[3]=(temp_speed)&0xff;
//      can_tdata[4]=(temp_Iq)>>24;
//			can_tdata[5]=(temp_Iq)>>16;
			can_tdata[4]=(temp_Iq)>>8;
			can_tdata[5]=(temp_Iq)&0xff;
      HAL_FDCAN_AddMessageToTxFifoQ(&hfdcan1,&pTxHeader1,can_tdata);
			switch(mode_select){
				case 0:{
					hctrl1.angle_Set =(uint16_t)((can_rxdata[1]<<8)|can_rxdata[2]);
					break;
					}
				case 1:{
//					if(can_rxdata[3]==0){
//					hctrl1.speed_Set = can_rxdata[4]; 
//					}else{
//					hctrl1.speed_Set = -can_rxdata[4];
//					}
					hctrl1.speed_Set = (int16_t)((can_rxdata[3]<<8)|can_rxdata[4]); 
					break;
					}
        case 2:{
//          if(can_rxdata[5]==0){
          hctrl1.Iq_Set = (int16_t)((can_rxdata[5]<<8)|can_rxdata[6])*1.2207f/1000.f;
//          }else{
//          hctrl1.Iq_Set = (uint16_t)((can_rxdata[6]<<8)|can_rxdata[7])*-0.00061f;
//          }
          break;

        }
				default:{

					}
				}
      }
      
    }else{
      hctrl1.speed_Set=0;
      hctrl1.Iq_Set = 0.f;
//TIM4 PRS=15999 ARR = 999 1CNT=100us 100ms MAX
//     if((TIM4->CR1&(1<<0))==1){
//       TIM4->CR1&=~(1<<0);
//       time_stamp = TIM4->CNT;
//       TIM4->CNT = 0;
//     }
//       TIM4->CR1|=(1<<0);
    }
//			cpu_usage=GetCPUUsage();
// osDelay(10);
  }
  /* USER CODE END CAN_Communication */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

/* USER CODE END Application */

