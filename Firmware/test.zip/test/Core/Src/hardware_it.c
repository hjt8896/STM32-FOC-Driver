#include "hardware_it.h"

/************************************************************current sensor interupt***********************************************/
//uint16_t adcbuf[3];

void HAL_ADCEx_InjectedConvCpltCallback(ADC_HandleTypeDef *hadc)
{
	static uint8_t adc_flag[]={0,0};
	float cos_Theta,sin_Theta;
	uint16_t adcbuf[3];
  /* Prevent unused argument(s) compilation warning */
  if(hadc==&hadc1){
	adcbuf[0]=hadc->Instance->JDR1; //opamp1  U
	adcbuf[2]=hadc->Instance->JDR2;  //opamp3 W voltage equcals real value(unit 1v) multiply (124800/11) offset 11
	adc_flag[0]=1;
	}else{
	adcbuf[1]=hadc->Instance->JDR1;//opamp2 V current(unit 1A) equals voltage divided by 3m omg
	adc_flag[1]=1;
	}
	if( (adc_flag[0]==1)&&(adc_flag[1]==1)){
	adc_flag[0]=0;
	adc_flag[1]=0;
	Get_CurrentSensor_data(adcbuf,&hcurrent_sensor1);
	Get_SpeedSensor_data(rdata,&hspeed_sensor1);
	Process_CurrentSensor_data(&cos_Theta,&sin_Theta,hspeed_sensor1.electronic_angle_us16,&hcurrent_sensor1);
	hctrl1.Id_ctrl_pid.pre_error = hctrl1.Id_ctrl_pid.error;
	hctrl1.Id_ctrl_pid.error = hctrl1.Id_Set - hcurrent_sensor1.Id;
	hctrl1.Id_ctrl_pid.output = PID_Controller(hctrl1.Id_ctrl_pid);

	hctrl1.Iq_ctrl_pid.pre_error = hctrl1.Iq_ctrl_pid.error;
	hctrl1.Iq_ctrl_pid.error = hctrl1.Iq_Set - hcurrent_sensor1.Iq;
	hctrl1.Iq_ctrl_pid.output = PID_Controller(hctrl1.Iq_ctrl_pid);
		
	arm_inv_park_f32(hctrl1.Id_ctrl_pid.output,hctrl1.Iq_ctrl_pid.output,&hctrl1.Iarpha_O,&hctrl1.Ibeta_O,sin_Theta,cos_Theta);

	hmotor_ctl.ms_svpwm->Uarpha = hctrl1.Iarpha_O;
	hmotor_ctl.ms_svpwm->Ubeta  = hctrl1.Ibeta_O; 	
	SVPWM_Generator(hmotor_ctl.ms_svpwm);
	}

}



/************************************************************speed sensor interupt***********************************************/
#if AS5600_PWM_MODE
uint16_t as5600_pwm_T = 0;  //unit 0.1us (delta_t)
uint16_t as5600_pwm_H = 0;  //unit 0.1us

void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{

	if(htim==&htim8){
	as5600_pwm_T = htim->Instance->CCR1;
	as5600_pwm_H = htim->Instance->CCR2;
	BaseType_t xHigherPriorityTaskWoken,xResult;
	xHigherPriorityTaskWoken = pdFALSE;	
	xResult=xEventGroupSetBitsFromISR(myEvent01Handle,(1<<1),&xHigherPriorityTaskWoken);
	if(xResult==pdPASS){
		portYIELD_FROM_ISR( xHigherPriorityTaskWoken );
		}
	
	}	

}
#endif

#if AS5048A_SPI_MODE 

//uint8_t spi_flag=0;
//uint8_t spi_flag2=0;
void HAL_SPI_RxCpltCallback(SPI_HandleTypeDef *hspi)
{
	static uint8_t pointer_count=0;
	static uint8_t count=0;
	static uint32_t m_angletemp=0;
	float temp_speed;
	SPI1->CR1 &=~(1<<6);

	__disable_irq();
//	spi_flag = 1;
	rdata = (data[2])|(data[3]<<8);
	rdata &=~(uint16_t)(3<<14);
	__enable_irq();
	pointer_count+=2;
	pointer_count %= 4;

	DMA1_Channel1->CCR&=~(1<<0);
	DMA1_Channel1->CMAR = (uint32_t)(dma_pointer+pointer_count);
	DMA1_Channel1->CCR|=(1<<0);

	m_angletemp+=rdata;
	count++;
	if(count==40){//500Hz
		count =0;
		hspeed_sensor1.pre_mechanical_angle_us16=m_angle;
		m_angle=(uint16_t)((655320-m_angletemp)/40.f);
		temp_speed = m_angle - hspeed_sensor1.pre_mechanical_angle_us16;
		if(temp_speed<600.f&&temp_speed>-600.f){
			hspeed_sensor1.delta_mechanical_angle_s16=
	           lowPassFilter(temp_speed,hspeed_sensor1.delta_mechanical_angle_s16,hspeed_sensor1.speed_filter);
		}
		m_angletemp=0;
	}
}
#endif

/************************************************************TIMx PeriodElapsed interupt***********************************************/
void My_TIMx_PeriodElapsed_Callback(TIM_HandleTypeDef *htim){
//speed loop interupt 4KHz
	if(htim->Instance == TIM4){
		hctrl1.speed_ctrl_pid.pre_error = hctrl1.speed_ctrl_pid.error;
		hctrl1.speed_ctrl_pid.error  = hctrl1.speed_Set - hspeed_sensor1.delta_mechanical_angle_s16; //
		hctrl1.speed_ctrl_pid.output = PID_Delta_Controller(hctrl1.speed_ctrl_pid);
		hctrl1.Iq_Set	+=	hctrl1.speed_ctrl_pid.output;
		
		if(hctrl1.Iq_Set>65){
		hctrl1.Iq_Set = 65;
		}else if(hctrl1.Iq_Set<-65){
		hctrl1.Iq_Set = -65;
		}
	}
#if AS5048A_SPI_MODE //speed sensor interupt 20KHz
  else if (htim->Instance == TIM3) {
	SPI1->CR1 |=(1<<6);
	}
#endif /*AS5048A_SPI_MODE*/

}

