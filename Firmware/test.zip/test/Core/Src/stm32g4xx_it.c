/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    stm32g4xx_it.c
  * @brief   Interrupt Service Routines.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32g4xx_it.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "hardware_it.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN TD */

/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
uint8_t dma_data[4];
uint8_t * dma_pointer = dma_data;
uint16_t spi_rdata;
extern uint8_t mode_select;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/* External variables --------------------------------------------------------*/
extern ADC_HandleTypeDef hadc1;
extern ADC_HandleTypeDef hadc2;
extern FDCAN_HandleTypeDef hfdcan1;
extern DMA_HandleTypeDef hdma_spi1_rx;
extern TIM_HandleTypeDef htim3;
extern TIM_HandleTypeDef htim4;
extern TIM_HandleTypeDef htim7;

/* USER CODE BEGIN EV */

/* USER CODE END EV */

/******************************************************************************/
/*           Cortex-M4 Processor Interruption and Exception Handlers          */
/******************************************************************************/
/**
  * @brief This function handles Non maskable interrupt.
  */
void NMI_Handler(void)
{
  /* USER CODE BEGIN NonMaskableInt_IRQn 0 */

  /* USER CODE END NonMaskableInt_IRQn 0 */
  /* USER CODE BEGIN NonMaskableInt_IRQn 1 */
   while (1)
  {
  }
  /* USER CODE END NonMaskableInt_IRQn 1 */
}

/**
  * @brief This function handles Hard fault interrupt.
  */
void HardFault_Handler(void)
{
  /* USER CODE BEGIN HardFault_IRQn 0 */

  /* USER CODE END HardFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_HardFault_IRQn 0 */
    /* USER CODE END W1_HardFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Memory management fault.
  */
void MemManage_Handler(void)
{
  /* USER CODE BEGIN MemoryManagement_IRQn 0 */

  /* USER CODE END MemoryManagement_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_MemoryManagement_IRQn 0 */
    /* USER CODE END W1_MemoryManagement_IRQn 0 */
  }
}

/**
  * @brief This function handles Prefetch fault, memory access fault.
  */
void BusFault_Handler(void)
{
  /* USER CODE BEGIN BusFault_IRQn 0 */

  /* USER CODE END BusFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_BusFault_IRQn 0 */
    /* USER CODE END W1_BusFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Undefined instruction or illegal state.
  */
void UsageFault_Handler(void)
{
  /* USER CODE BEGIN UsageFault_IRQn 0 */

  /* USER CODE END UsageFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_UsageFault_IRQn 0 */
    /* USER CODE END W1_UsageFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Debug monitor.
  */
void DebugMon_Handler(void)
{
  /* USER CODE BEGIN DebugMonitor_IRQn 0 */

  /* USER CODE END DebugMonitor_IRQn 0 */
  /* USER CODE BEGIN DebugMonitor_IRQn 1 */

  /* USER CODE END DebugMonitor_IRQn 1 */
}

/******************************************************************************/
/* STM32G4xx Peripheral Interrupt Handlers                                    */
/* Add here the Interrupt Handlers for the used peripherals.                  */
/* For the available peripheral interrupt handler names,                      */
/* please refer to the startup file (startup_stm32g4xx.s).                    */
/******************************************************************************/

/**
  * @brief This function handles DMA1 channel1 global interrupt.
  */
void DMA1_Channel1_IRQHandler(void)
{
  /* USER CODE BEGIN DMA1_Channel1_IRQn 0 */
	static uint16_t m_angle;
  /* USER CODE END DMA1_Channel1_IRQn 0 */
//  HAL_DMA_IRQHandler(&hdma_spi1_rx);
  /* USER CODE BEGIN DMA1_Channel1_IRQn 1 */
	static uint8_t pointer_count=0;
	static uint8_t count=0;
	float temp_speed;
	DMA1->IFCR|=1<<0;
	SPI1->CR1 &=~(1<<6);

  __disable_irq();
	spi_rdata = (dma_data[0])|(dma_data[1]<<8);
	spi_rdata &=~(uint16_t)(3<<14);
	__enable_irq();

	pointer_count+=2;
	pointer_count %= 4;

	DMA1_Channel1->CCR&=~(1<<0);
	DMA1_Channel1->CMAR = (uint32_t)(dma_pointer+pointer_count);
	DMA1_Channel1->CCR|=(1<<0);

	count++;
	if(count==200){//200Hz
		count =0;
		hspeed_sensor1.pre_mechanical_angle_us16=m_angle;
    m_angle=hspeed_sensor1.mechanical_angle_us16;
		temp_speed = m_angle - hspeed_sensor1.pre_mechanical_angle_us16;
		if(temp_speed<1100.f&&temp_speed>-1100.f){
			hspeed_sensor1.delta_mechanical_angle_s16=
	           lowPassFilter(temp_speed,hspeed_sensor1.delta_mechanical_angle_s16,hspeed_sensor1.speed_filter);
		}
	}
  /* USER CODE END DMA1_Channel1_IRQn 1 */
}

/**
  * @brief This function handles ADC1 and ADC2 global interrupt.
  */
void ADC1_2_IRQHandler(void)
{
  /* USER CODE BEGIN ADC1_2_IRQn 0 */

  /* USER CODE END ADC1_2_IRQn 0 */
//  HAL_ADC_IRQHandler(&hadc1);
//  HAL_ADC_IRQHandler(&hadc2);
  /* USER CODE BEGIN ADC1_2_IRQn 1 */
	float cos_Theta,sin_Theta;
	uint16_t adcbuf[3];
	float Ua,Ub;
	LL_ADC_ClearFlag_JEOS(ADC2);
  /* Prevent unused argument(s) compilation warning */

	adcbuf[0]=ADC1->JDR1; //opamp1  U
	adcbuf[2]=ADC1->JDR2;  //opamp3 W voltage equcals real value(unit 1v) multiply (124800/11) offset 11
	adcbuf[1]=ADC2->JDR1;//opamp2 V current(unit 1A) equals voltage divided by 3m omg

	Get_CurrentSensor_data(adcbuf,&hcurrent_sensor1);
	Get_SpeedSensor_data(spi_rdata,&hspeed_sensor1);
	Process_CurrentSensor_data(&cos_Theta,&sin_Theta,hspeed_sensor1.electronic_angle_us16,&hcurrent_sensor1);
	hctrl1.Id_ctrl_pid.pre_error = hctrl1.Id_ctrl_pid.error;
	hctrl1.Id_ctrl_pid.error = hctrl1.Id_Set - hcurrent_sensor1.Id;
	PID_Controller(&(hctrl1.Id_ctrl_pid));

	hctrl1.Iq_ctrl_pid.pre_error = hctrl1.Iq_ctrl_pid.error;
	hctrl1.Iq_ctrl_pid.error = hctrl1.Iq_Set - hcurrent_sensor1.Iq;
  PID_Controller(&(hctrl1.Iq_ctrl_pid));
/*Idq pid_out=Udq*/		
	arm_inv_park_f32(hctrl1.Id_ctrl_pid.output,hctrl1.Iq_ctrl_pid.output,&Ua,&Ub,sin_Theta,cos_Theta);

	svpwm_handle.Uarpha = Ua;
	svpwm_handle.Ubeta  = Ub; 	
	SVPWM_Generator(&svpwm_handle);
  /* USER CODE END ADC1_2_IRQn 1 */
}

/**
  * @brief This function handles FDCAN1 interrupt 0.
  */
void FDCAN1_IT0_IRQHandler(void)
{
  /* USER CODE BEGIN FDCAN1_IT0_IRQn 0 */

  /* USER CODE END FDCAN1_IT0_IRQn 0 */
  HAL_FDCAN_IRQHandler(&hfdcan1);
  /* USER CODE BEGIN FDCAN1_IT0_IRQn 1 */

  /* USER CODE END FDCAN1_IT0_IRQn 1 */
}

/**
  * @brief This function handles TIM3 global interrupt.
  */
void TIM3_IRQHandler(void)
{
  /* USER CODE BEGIN TIM3_IRQn 0 */

  /* USER CODE END TIM3_IRQn 0 */
//  HAL_TIM_IRQHandler(&htim3);
  /* USER CODE BEGIN TIM3_IRQn 1 */
	TIM3->SR = ~(TIM_SR_UIF);
	SPI1->CR1 |=(1<<6);
  /* USER CODE END TIM3_IRQn 1 */
}

/**
  * @brief This function handles TIM4 global interrupt.
  */
void TIM4_IRQHandler(void)
{
  /* USER CODE BEGIN TIM4_IRQn 0 */

  /* USER CODE END TIM4_IRQn 0 */
//  HAL_TIM_IRQHandler(&htim4);
  /* USER CODE BEGIN TIM4_IRQn 1 */
	TIM4->SR = ~(TIM_SR_UIF);
//	if(mode_select<2){
//	hctrl1.speed_ctrl_pid.pre_error = hctrl1.speed_ctrl_pid.error;
//	hctrl1.speed_ctrl_pid.error  = hctrl1.speed_Set - hspeed_sensor1.delta_mechanical_angle_s16; //
//	PID_Controller(&(hctrl1.speed_ctrl_pid));
//  __disable_irq();
//	hctrl1.Iq_Set	=	hctrl1.speed_ctrl_pid.output;
//	__enable_irq();
//	}
	
  /* USER CODE END TIM4_IRQn 1 */
}

/**
  * @brief This function handles TIM7 global interrupt.
  */
void TIM7_IRQHandler(void)
{
  /* USER CODE BEGIN TIM7_IRQn 0 */

  /* USER CODE END TIM7_IRQn 0 */
  HAL_TIM_IRQHandler(&htim7);
  /* USER CODE BEGIN TIM7_IRQn 1 */

  /* USER CODE END TIM7_IRQn 1 */
}

/* USER CODE BEGIN 1 */

/* USER CODE END 1 */
