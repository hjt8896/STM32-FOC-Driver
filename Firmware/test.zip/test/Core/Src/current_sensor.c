#include "current_sensor.h"

CurrentSensor_HandleTypeDef hcurrent_sensor1;

void Get_CurrentSensor_data(uint16_t *adc_data,CurrentSensor_HandleTypeDef *hcurrent_sensor){
	
	hcurrent_sensor->Iu = (int16_t)(adc_data[0]-2541);
	hcurrent_sensor->Iv = (int16_t)(adc_data[1]-2541);
	hcurrent_sensor->Iw = (int16_t)(adc_data[2]-2530);

}


void Process_CurrentSensor_data(float *cos_theta,float *sin_theta, uint32_t ele_angle_s16,CurrentSensor_HandleTypeDef *hcurrent_sensor){
	float tempIdq;

	*cos_theta = cosf(6.2832f*ele_angle_s16/16383.f);
	*sin_theta = sinf(6.2832f*ele_angle_s16/16383.f);
	
	float pre_tempIdq=hcurrent_sensor->Id;
	tempIdq=(hcurrent_sensor->Iu*(*cos_theta) + hcurrent_sensor->Iv*(-0.5f*(*cos_theta)+0.866f*(*sin_theta)) 
										+ hcurrent_sensor->Iw*(-0.5f*(*cos_theta)-0.866f*(*sin_theta)));
	hcurrent_sensor->Id=lowPassFilter(-tempIdq*0.6667f,pre_tempIdq,hcurrent_sensor->dq_filter);
	
	pre_tempIdq=hcurrent_sensor->Iq;
	tempIdq=(hcurrent_sensor->Iu*(-*sin_theta) + hcurrent_sensor->Iv*(0.5f*(*sin_theta)+0.866f*(*cos_theta)) 
										+ hcurrent_sensor->Iw*(0.5f*(*sin_theta)-0.866f*(*cos_theta)));		
	hcurrent_sensor->Iq=lowPassFilter(-tempIdq*0.6667f,pre_tempIdq,hcurrent_sensor->dq_filter);

}


