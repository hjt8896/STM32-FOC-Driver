#include "speed_position_sensor.h"
#include "my_utilities.h"
#include "hardware_it.h"

SpeedSensor_HandleTypeDef hspeed_sensor1;

#if AS5048A_SPI_MODE
void Get_SpeedSensor_data(uint16_t data,SpeedSensor_HandleTypeDef *hspeed_sensor){

	hspeed_sensor->mechanical_angle_us16 =16383 - data;

	int16_t temp = (hspeed_sensor->mechanical_angle_us16 - ZERO_M_ANGLE_US16);
	if(temp>=0){
		hspeed_sensor->electronic_angle_us16 = (temp*11)%16383;
		}else{
		hspeed_sensor->electronic_angle_us16 = (11*(temp+16383))%16383;
		}
	
}
#endif

