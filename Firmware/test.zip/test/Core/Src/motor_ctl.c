#include "motor_ctl.h"
#include "current_sensor.h"

Control_HandleTyprDef 								hctrl1;
