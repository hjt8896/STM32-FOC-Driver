#include "svpwm.h"

const uint8_t N2Sector[] = {
    0, 2, 6, 1, 4, 3, 5};
const uint8_t V2T_Table[][3] = {//Vector2Timer
    {0, 0, 0}, {1, 0, 0}, {1, 1, 0}, {0, 1, 0}, {0, 1, 1}, {0, 0, 1}, {1, 0, 1}, {1, 1, 1}};//
const uint8_t V_C_Table[][2] = {{3, 3}, {1, 0}, {2, 1}, {0, 2}, {1, 0}, {2, 1}, {0, 2}};//vector culculate table,{3,3}no use

SVPWM_HandleTypeDef svpwm_handle;
/**
  * @brief  This function is used to generate SVPWM signal
  * @param  Ua: y in Cartesian coordinate; Ub: x in Cartesian coordinate; svpwm: 
  * @retval 0 success; 1 fail
  */
uint8_t SVPWM_Generator(SVPWM_HandleTypeDef *svpwm)
{
  float temp=0;
  uint8_t A, B, C;
//
  svpwm->K = 1.73205f  / Udc;
	
	
//SectorNum
  svpwm->U[0] = svpwm->Ubeta;
  svpwm->U[1] = 0.5f*(1.73205f * svpwm->Uarpha - svpwm->Ubeta);
  svpwm->U[2] = 0.5f*(-1.73205f * svpwm->Uarpha - svpwm->Ubeta);
	
  A = (svpwm->U[0]) > 0 ? 1 : 0;
  B = (svpwm->U[1]) > 0 ? 1 : 0;
  C = (svpwm->U[2]) > 0 ? 1 : 0;

  svpwm->N = 4 * C + 2 * B + A;
  svpwm->SectorNum = N2Sector[svpwm->N];
	
  if (svpwm->SectorNum)//
  {
    svpwm->Tvector[svpwm->SectorNum] = fabsf(svpwm->K * svpwm->U[V_C_Table[svpwm->SectorNum][0]]);
    svpwm->Tvector[(svpwm->SectorNum % 6) + 1] = fabsf(svpwm->K * svpwm->U[V_C_Table[svpwm->SectorNum][1]]);		
		svpwm->Tvector[0] = 0.5f * (1 - (svpwm->Tvector[svpwm->SectorNum]) - (svpwm->Tvector[(svpwm->SectorNum % 6) + 1]));
    svpwm->Tvector[7] = svpwm->Tvector[0];
		
    for (int i = 1; i < 7; i++)
    {
      if (i != (svpwm->SectorNum) && i != ((svpwm->SectorNum % 6) + 1))
      {
        svpwm->Tvector[i] = 0;//
      }
    }
		
    for (int i = 0; i < 3; i++)//
    {
      for (int n = 0; n < 8; n++){
			temp += svpwm->Tvector[n] * V2T_Table[n][i];
			}    
      svpwm->Ttim[i] = temp;
      temp = 0;
    }
		TIM1->CCR1 = (uint32_t)(((svpwm->Ttim[0]))*3999.f);
    TIM1->CCR2 = (uint32_t)(((svpwm->Ttim[1]))*3999.f);
    TIM1->CCR3 = (uint32_t)(((svpwm->Ttim[2]))*3999.f);
    return 0;
  }
  else
    return 1;
}


