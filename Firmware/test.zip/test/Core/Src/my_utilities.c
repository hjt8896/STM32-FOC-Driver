#include "my_utilities.h"

float lowPassFilter(float input, float prevOutput, float alpha) {
    return alpha * input + (1.0f - alpha) * prevOutput;
}

/**
  * @brief  This function is used to generate PID(position) output
  * @param  Kp,Ki,Kd,error
  * @retval output
  */

void PID_Controller(PID_HandleTypeDef *hctrl_pid){
	float out;
	hctrl_pid->Integral+= hctrl_pid->pre_error;
	if(hctrl_pid->Integral>hctrl_pid->Integral_limit){

	hctrl_pid->Integral= hctrl_pid->Integral_limit;
	
	}else if (hctrl_pid->Integral< -hctrl_pid->Integral_limit){

	hctrl_pid->Integral= -hctrl_pid->Integral_limit;

	}
	out = hctrl_pid->error * hctrl_pid->Kp
				+ (hctrl_pid->error - hctrl_pid->pre_error)*hctrl_pid->Kd/hctrl_pid->dt
				+ (hctrl_pid->Integral+0.5f*hctrl_pid->error)*hctrl_pid->Ki *hctrl_pid->dt;
	if(out>hctrl_pid->Max_output){
	out = hctrl_pid->Max_output;
	}else if(out<hctrl_pid->Min_output){
	out = hctrl_pid->Min_output;
	}
	hctrl_pid->output = out;
}



