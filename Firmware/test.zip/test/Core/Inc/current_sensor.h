#ifndef __CURRENT_SENSOR_H
#define __CURRENT_SENSOR_H
#include "main.h"
#include "MATH.h"
#include "my_utilities.h"

typedef struct{
float Id;
float Iq;
	
int16_t Iu;
int16_t Iv;	
int16_t Iw;

float Iarpha;
float Ibeta;
float dq_filter; //0.5
float uvw_filter; //0.5
}CurrentSensor_HandleTypeDef;

extern CurrentSensor_HandleTypeDef hcurrent_sensor1;
void Get_CurrentSensor_data(uint16_t *adc,CurrentSensor_HandleTypeDef *hcurrent_sensor);
void Process_CurrentSensor_data(float *cos_theta,float *sin_theta, uint32_t ele_angle_s16,CurrentSensor_HandleTypeDef *hcurrent_sensor);
#endif /*__CURRENT_SENSOR_H*/

