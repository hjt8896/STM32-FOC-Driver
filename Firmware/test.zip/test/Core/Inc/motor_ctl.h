#ifndef __MOTOR_CTL_H
#define __MOTOR_CTL_H
#include "my_utilities.h"
#include "svpwm.h"
#include "speed_position_sensor.h"


typedef struct{
float Id_Set;
float Iq_Set;
//float torque_set;
float speed_Set;
float angle_Set;
PID_HandleTypeDef speed_ctrl_pid;
PID_HandleTypeDef position_ctrl_pid;
PID_HandleTypeDef	Id_ctrl_pid;
PID_HandleTypeDef	Iq_ctrl_pid;
}Control_HandleTyprDef;

extern Control_HandleTyprDef hctrl1;

#endif /* __MOTOR_CTL_H */

