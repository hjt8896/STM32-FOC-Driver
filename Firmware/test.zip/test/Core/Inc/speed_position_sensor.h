#ifndef __SPS_H
#define __SPS_H

#include "main.h"
#include "MATH.h"
#include "encoder.h"

#define AS5048A_SPI_MODE 1
#define AS5600_PWM_MODE 0

typedef struct{
uint16_t mechanical_angle_us16;             //s16degree format  65535*((4351/4095)*(H/T)-128/4095)
uint16_t pre_mechanical_angle_us16;
int16_t pre_delta_mechanical_angle_s16;
int16_t delta_mechanical_angle_s16;
int16_t delta_mechanical_speed_s16;
uint16_t delta_t;														//unit 10us
uint32_t electronic_angle_us16;  						//unit degree

float speed_filter;
float acc_filter;
}SpeedSensor_HandleTypeDef;

extern SpeedSensor_HandleTypeDef hspeed_sensor1;


#if AS5048A_SPI_MODE
#include "spi.h"
#define ZERO_M_ANGLE_US16 						5648
void Get_SpeedSensor_data(uint16_t spi_data,SpeedSensor_HandleTypeDef *hspeed_sensor);
#endif
#endif /*__SPS_H*/

