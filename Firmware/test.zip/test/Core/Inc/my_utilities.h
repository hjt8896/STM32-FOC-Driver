#ifndef __MY_UTILITIES_H__
#define __MY_UTILITIES_H__

#include "main.h"
#include "MATH.h"
#include "dsp/controller_functions.h"


typedef struct{
float Kp;
float Ki;
float Kd;
float error;
float pre_error;
float Integral;
float Integral_limit;
float Max_output;
float Min_output;
float output;
float dt;
}PID_HandleTypeDef;

float lowPassFilter(float input, float prevOutput, float alpha);
void PID_Controller(PID_HandleTypeDef *hctrl_pid);

#endif /*__MY_UTILITIES_H__*/


