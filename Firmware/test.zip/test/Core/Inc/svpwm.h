#ifndef __SVPWM_H
#define __SVPWM_H

#include "main.h"
#include "MATH.h"
#include "arm_math.h"
#define ABS(a) ((a >= 0) ? (a) : (-a))
#define Degree2Rad(a) a / 360.f * 2 * 3.1416
#define Udc 12.f


typedef struct
{
  float Uarpha,
      Ubeta;
  float U[3];
  float Tvector[8];
  float K;
  float Ttim[3];
  uint32_t CCR[3];
  uint8_t N;
  uint8_t SectorNum;
  /* data */
} SVPWM_HandleTypeDef;

extern SVPWM_HandleTypeDef svpwm_handle;
uint8_t SVPWM_Generator(SVPWM_HandleTypeDef *svpwm);

#endif /* __SVPWM_H */

