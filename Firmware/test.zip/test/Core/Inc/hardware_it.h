#ifndef __HARDWARE_IT_H__
#define __HARDWARE_IT_H__

#include "speed_position_sensor.h"
#include "my_utilities.h"
#include "main.h"
#include "cmsis_os.h"
#include "adc.h"
//#include "dma.h"
#include "fdcan.h"
#include "opamp.h"
#include "spi.h"
#include "tim.h"
#include "gpio.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "event_groups.h"
#include "motor_ctl.h"
#include "current_sensor.h"
#include "speed_position_sensor.h"
//extern uint16_t adcbuf[3];
extern uint8_t data[4];
extern uint8_t * dma_pointer;
#endif /* __HARDWARE_IT_H__ */

