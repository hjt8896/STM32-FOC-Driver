
#ifndef __ENCODER_H__
#define __ENCODER_H__
#include "main.h"

#define M_PI                          (3.1416f)
#define DEGREE_2_RAD(degee)           (degree*0.03491f)  //degree/180*2PI
#define FLOAT_2_Q15(x)								(int16_t)(x*32768.f)
#define Q15_2_FLOAT(x)								(float)(x/32768.f)


#endif /* __ENCODER_H__ */

